package com.example.focusboard

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmActivity : Activity() {
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "FOCUS BLOCK COMPLETE\\n\\nYou completed 50 minutes of deep work. Take your 10-minute rest."
            textSize = 24f
        })
        layout.addView(Button(this).apply {
            text = "Dismiss alarm"
            setOnClickListener {
                stopAlarm()
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(72)
                finish()
            }
        })
        setContentView(layout)
        startAlarm()
    }

    private fun startAlarm() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmActivity, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) { }
    }

    private fun stopAlarm() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // Dismiss only through the on-screen button.
    }

    override fun onDestroy() {
        stopAlarm()
        super.onDestroy()
    }
}
