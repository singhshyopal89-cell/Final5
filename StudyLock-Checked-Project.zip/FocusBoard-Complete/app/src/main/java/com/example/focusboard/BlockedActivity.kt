package com.example.focusboard

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "Focus session active\\n\\nThis app is on your distraction list. Return to your study task and continue after your focus block."
            textSize = 22f
        })
        layout.addView(Button(this).apply {
            text = "Return to studying"
            setOnClickListener { finish() }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // Keep the reminder screen visible; use the explicit button.
    }
}
