package com.example.focusboard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageNameSeen = event.packageName?.toString() ?: return
        if (packageNameSeen == packageName) return
        val prefs = getSharedPreferences("focusboard", MODE_PRIVATE)
        if (!prefs.getBoolean("focus_running", false)) return
        val blocked = prefs.getStringSet("blocked_apps", emptySet()) ?: emptySet()
        if (!blocked.contains(packageNameSeen)) return

        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_block_screen", 0L)
        if (now - last < 1200L) return
        prefs.edit().putLong("last_block_screen", now).apply()
        val intent = Intent(this, BlockedActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("package_name", packageNameSeen)
        startActivity(intent)
    }

    override fun onInterrupt() = Unit
}
