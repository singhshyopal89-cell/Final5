package com.example.focusboard

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.time.LocalDate

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var permissionText: TextView
    private lateinit var planContainer: LinearLayout
    private lateinit var syllabusInput: EditText
    private lateinit var dateInput: EditText
    private val prefs by lazy { getSharedPreferences("focusboard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        permissionText = findViewById(R.id.permissionText)
        planContainer = findViewById(R.id.planContainer)
        syllabusInput = findViewById(R.id.syllabusInput)
        dateInput = findViewById(R.id.dateInput)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 301)
        }
        findViewById<Button>(R.id.pickAppsButton).setOnClickListener { showAppPicker() }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.dndButton).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 23) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }
        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Enable FocusBoard in Accessibility settings first.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                val i = Intent(this, FocusService::class.java).setAction(FocusService.ACTION_START)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                status.text = "Focus session started: 50 minutes"
            }
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            startService(Intent(this, FocusService::class.java).setAction(FocusService.ACTION_STOP))
            status.text = "Focus session stopped."
        }
        findViewById<Button>(R.id.generateButton).setOnClickListener { generatePlan() }

        syllabusInput.setText(prefs.getString("syllabus", ""))
        dateInput.setText(prefs.getString("deadline", ""))
        renderPlan()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        val dnd = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val dndText = if (Build.VERSION.SDK_INT < 23 || dnd.isNotificationPolicyAccessGranted) "DND allowed" else "DND not allowed"
        permissionText.text = "Accessibility: ${if (isAccessibilityEnabled()) "enabled" else "not enabled"}  •  $dndText"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${FocusAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun showAppPicker() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val selected = prefs.getStringSet("blocked_apps", emptySet())?.toMutableSet() ?: mutableSetOf()
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val checked = apps.map { selected.contains(it.activityInfo.packageName) }.toBooleanArray()

        AlertDialog.Builder(this).setTitle("Select distracting apps")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                val pkg = apps[which].activityInfo.packageName
                if (isChecked) selected.add(pkg) else selected.remove(pkg)
            }
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putStringSet("blocked_apps", selected).apply()
                Toast.makeText(this, "${selected.size} distracting apps saved.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun generatePlan() {
        val raw = syllabusInput.text.toString()
        val deadlineText = dateInput.text.toString().trim()
        try {
            val chapters = parseChapters(raw)
            val deadline = LocalDate.parse(deadlineText)
            require(chapters.isNotEmpty()) { "Enter at least one chapter." }
            require(!deadline.isBefore(LocalDate.now())) { "Date must be today or later." }
            prefs.edit().putString("syllabus", raw).putString("deadline", deadlineText).apply()
            PlannerStore.saveChapters(this, chapters)
            PlannerStore.saveDeadline(this, deadline.toString())
            renderPlan()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Check the syllabus and date format.", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseChapters(raw: String): List<StudyChapter> =
        raw.lines().flatMap { line ->
            if (!line.contains(":")) emptyList() else {
                val subject = line.substringBefore(":").trim()
                line.substringAfter(":").split(",").map { it.trim() }
                    .filter { it.isNotBlank() && subject.isNotBlank() }
                    .map { StudyChapter(subject, it) }
            }
        }

    private fun renderPlan() {
        planContainer.removeAllViews()
        val chapters = PlannerStore.loadChapters(this)
        val deadline = PlannerStore.loadDeadline(this)
        if (chapters.isEmpty() || deadline == null) {
            planContainer.addView(TextView(this).apply { text = "Your daily targets will appear here." })
            return
        }
        val days = StudyPlanner.recalculate(chapters, PlannerStore.completed(this),
            LocalDate.now(), LocalDate.parse(deadline))
        days.forEach { day ->
            planContainer.addView(TextView(this).apply {
                text = "${day.date}  •  ${day.title}"
                textSize = 17f
                setPadding(0, 18, 0, 6)
            })
            day.items.forEach { item ->
                if (item.type == "chapter") {
                    planContainer.addView(CheckBox(this).apply {
                        text = item.label
                        isChecked = PlannerStore.isCompleted(this@MainActivity, item.key)
                        setOnCheckedChangeListener { _, checked ->
                            PlannerStore.setCompleted(this@MainActivity, item.key, checked)
                            renderPlan()
                        }
                    })
                } else {
                    planContainer.addView(TextView(this).apply {
                        text = "• ${item.label}"
                        textSize = 14f
                        setPadding(24, 5, 0, 5)
                    })
                }
            }
        }
        planContainer.addView(TextView(this).apply {
            text = "\\nTick chapters as you complete them. Completed chapters are removed when the plan is recalculated."
            textSize = 12f
        })
    }
}
