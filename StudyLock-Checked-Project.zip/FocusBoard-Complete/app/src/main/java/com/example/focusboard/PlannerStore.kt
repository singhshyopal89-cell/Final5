package com.example.focusboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class StudyChapter(val subject: String, val name: String) {
    val key: String get() = "$subject::$name"
}
data class PlanItem(val key: String, val label: String, val type: String)
data class PlanDay(val date: String, val title: String, val items: List<PlanItem>)

object PlannerStore {
    private fun prefs(c: Context) = c.getSharedPreferences("focusboard", Context.MODE_PRIVATE)

    fun saveChapters(c: Context, chapters: List<StudyChapter>) {
        val a = JSONArray()
        chapters.forEach { a.put(JSONObject().put("subject", it.subject).put("name", it.name)) }
        prefs(c).edit().putString("chapters_json", a.toString()).apply()
    }

    fun loadChapters(c: Context): List<StudyChapter> {
        val raw = prefs(c).getString("chapters_json", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            StudyChapter(o.getString("subject"), o.getString("name"))
        }
    }

    fun saveDeadline(c: Context, date: String) { prefs(c).edit().putString("planner_deadline", date).apply() }
    fun loadDeadline(c: Context): String? = prefs(c).getString("planner_deadline", null)

    fun completed(c: Context): Set<String> = prefs(c).getStringSet("completed_chapters", emptySet()) ?: emptySet()
    fun isCompleted(c: Context, key: String): Boolean = completed(c).contains(key)
    fun setCompleted(c: Context, key: String, value: Boolean) {
        val set = completed(c).toMutableSet()
        if (value) set.add(key) else set.remove(key)
        prefs(c).edit().putStringSet("completed_chapters", set).apply()
    }
    fun clearCompletion(c: Context) { prefs(c).edit().remove("completed_chapters").apply() }
}

object StudyPlanner {
    // Groups of up to four chapters are followed by a dedicated revision day.
    // Recalculation removes completed chapters and rebalances remaining work.
    fun recalculate(
        chapters: List<StudyChapter>,
        completed: Set<String>,
        today: java.time.LocalDate,
        deadline: java.time.LocalDate
    ): List<PlanDay> {
        require(!deadline.isBefore(today)) { "Deadline has passed." }
        val remaining = chapters.filterNot { completed.contains(it.key) }
        val daysAvailable = java.time.temporal.ChronoUnit.DAYS.between(today, deadline).toInt() + 1
        val groups = remaining.chunked(4)
        // Reserve up to three mock days, but only after making room for one
        // chapter-work day and one dedicated revision day per chapter group.
        val mockCapacity = (daysAvailable - groups.size * 2).coerceAtLeast(0)
        val mockDays = if (daysAvailable >= 10) minOf(3, mockCapacity) else 0
        val studyDays = (daysAvailable - mockDays).coerceAtLeast(1)
        val revisionDays = groups.size
        val chapterDays = (studyDays - revisionDays).coerceAtLeast(1)
        require(groups.isEmpty() || studyDays >= groups.size * 2) {
            "There are too many remaining chapters for this deadline while keeping revision days. Extend the target date or reduce the remaining chapter list."
        }
        val output = mutableListOf<PlanDay>()
        var date = today
        var usedChapterDays = 0

        groups.forEachIndexed { groupIndex, group ->
            val groupsLeft = groups.size - groupIndex
            val daysLeft = (chapterDays - usedChapterDays).coerceAtLeast(1)
            val daysForGroup = if (groupsLeft == 1) daysLeft
                else (daysLeft - (groupsLeft - 1)).coerceAtLeast(1)
            val perDay = kotlin.math.ceil(group.size.toDouble() / daysForGroup).toInt().coerceAtLeast(1)
            group.chunked(perDay).forEach { chunk ->
                output.add(PlanDay(date.toString(), "Chapter targets",
                    chunk.map { PlanItem(it.key, "${it.subject}: ${it.name}", "chapter") }))
                date = date.plusDays(1)
                usedChapterDays++
            }
            output.add(PlanDay(date.toString(), "Dedicated revision day", listOf(
                PlanItem("revision-$date", "Revise the previous ${group.size} chapters", "revision"),
                PlanItem("question-bank-$date", "Solve NCERT / CBSE question-bank questions", "question")
            )))
            date = date.plusDays(1)
        }

        while (output.size < studyDays) {
            output.add(PlanDay(date.toString(), "Buffer / catch-up", listOf(
                PlanItem("buffer-$date", "Catch up on pending work or revise weak topics", "buffer")
            )))
            date = date.plusDays(1)
        }
        repeat(mockDays) {
            output.add(PlanDay(date.toString(), "Sample paper day", listOf(
                PlanItem("mock-$date", "3-hour full-length CBSE sample paper", "mock"),
                PlanItem("mock-review-$date", "Check answers and record weak topics", "review")
            )))
            date = date.plusDays(1)
        }
        return output
    }
}
