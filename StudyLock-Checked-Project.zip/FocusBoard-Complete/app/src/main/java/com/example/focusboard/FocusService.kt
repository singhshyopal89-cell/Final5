package com.example.focusboard

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.app.NotificationManager
import androidx.core.app.NotificationCompat

class FocusService : Service() {
    companion object {
        const val ACTION_START = "com.example.focusboard.START"
        const val ACTION_STOP = "com.example.focusboard.STOP"
        private const val CHANNEL = "focus_session"
        private const val NOTIFICATION_ID = 41
    }

    private var timer: CountDownTimer? = null
    private var remaining = 50 * 60 * 1000L
    private var previousInterruptionFilter: Int? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startFocus()
            ACTION_STOP -> stopSession()
        }
        return START_NOT_STICKY
    }

    private fun startFocus() {
        timer?.cancel()
        remaining = 50 * 60 * 1000L
        getSharedPreferences("focusboard", MODE_PRIVATE).edit()
            .putBoolean("focus_running", true).apply()
        startForeground(NOTIFICATION_ID, buildNotification("Deep focus: 50:00 remaining"))
        enableDndIfAuthorized()
        runFocusTimer()
    }

    private fun runFocusTimer() {
        timer = object : CountDownTimer(remaining, 1000L) {
            override fun onTick(ms: Long) {
                remaining = ms
                updateNotification("Deep focus: ${format(ms)} remaining")
            }
            override fun onFinish() {
                getSharedPreferences("focusboard", MODE_PRIVATE).edit()
                    .putBoolean("focus_running", false).apply()
                restoreDnd()
                showCompletionNotification()
                runRestTimer()
            }
        }.start()
    }

    private fun runRestTimer() {
        remaining = 10 * 60 * 1000L
        updateNotification("Rest break: 10:00 remaining")
        timer = object : CountDownTimer(remaining, 1000L) {
            override fun onTick(ms: Long) {
                remaining = ms
                updateNotification("Rest break: ${format(ms)} remaining")
            }
            override fun onFinish() {
                updateNotification("Break complete — next 50-minute focus block starting")
                startFocus()
            }
        }.start()
    }

    private fun enableDndIfAuthorized() {
        if (Build.VERSION.SDK_INT < 23) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!manager.isNotificationPolicyAccessGranted) return
        try {
            previousInterruptionFilter = manager.currentInterruptionFilter
            getSharedPreferences("focusboard", MODE_PRIVATE).edit()
                .putInt("previous_dnd_filter", previousInterruptionFilter!!)
                .putBoolean("dnd_was_changed", true).apply()
            manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        } catch (_: SecurityException) { }
    }

    private fun restoreDnd() {
        if (Build.VERSION.SDK_INT < 23) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val p = getSharedPreferences("focusboard", MODE_PRIVATE)
        val previous = previousInterruptionFilter ?: if (p.getBoolean("dnd_was_changed", false))
            p.getInt("previous_dnd_filter", NotificationManager.INTERRUPTION_FILTER_ALL) else return
        try {
            if (manager.isNotificationPolicyAccessGranted) manager.setInterruptionFilter(previous)
        } catch (_: SecurityException) { }
        previousInterruptionFilter = null
        p.edit().putBoolean("dnd_was_changed", false).apply()
    }

    private fun showCompletionNotification() {
        val alarmIntent = Intent(this, AlarmActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(this, 72, alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("FocusBoard: 50 minutes completed")
            .setContentText("Tap to open and dismiss your focus alarm.")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .setAutoCancel(false)
            .build()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(72, notification)
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("FocusBoard").setContentText(text)
            .setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Focus sessions", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Focus timer and completion alerts"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun format(ms: Long): String =
        "${ms / 60000}:${((ms % 60000) / 1000).toString().padStart(2, '0')}"

    private fun stopSession() {
        timer?.cancel()
        getSharedPreferences("focusboard", MODE_PRIVATE).edit()
            .putBoolean("focus_running", false).apply()
        restoreDnd()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
