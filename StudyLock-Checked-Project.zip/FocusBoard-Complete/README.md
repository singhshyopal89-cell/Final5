# StudyLock — FocusBoard 2.1 Native Android study app

## Included modules

### Strict Mode focus engine
- User selects launcher-visible apps to restrict.
- A user-enabled Accessibility service detects when a selected app becomes foreground and displays a return-to-study screen.
- Focus timer runs as a foreground service: 50 minutes focus followed by 10 minutes rest.
- DND access is requested from Android Settings. When access is granted, DND is enabled for the focus block and the prior interruption filter is restored when focus ends.
- Completion notification opens an alarm screen. The alarm uses the device's configured alarm sound and requires tapping the on-screen dismiss button.

### CBSE syllabus scheduler
- Enter subjects as `Subject: Chapter A, Chapter B`.
- The planner stores the syllabus and deadline on device.
- It schedules groups of up to four chapters, followed by a dedicated revision/question-bank day.
- Chapter checkboxes persist completion. When the plan is regenerated/reopened, completed chapters are filtered out and unfinished chapters are redistributed across remaining days.
- When at least 10 days are available and the remaining workload leaves room, it reserves up to the final three days for three-hour sample-paper sessions and answer review. If the workload cannot fit with dedicated revision days, the planner asks you to extend the deadline or reduce the remaining list rather than pretending the date can be guaranteed.

## Important Android limitations (not bugs)
- Android does not let ordinary apps force alarm volume to maximum or override silent mode. FocusBoard uses the alarm audio channel and the user's configured alarm volume.
- DND has to be granted by the user. DND exceptions, emergency alerts, manufacturer behavior and OS policy can still allow some calls/alerts.
- Accessibility app blocking is user-authorized and best-effort. Users can turn the service off, force-stop the app, reboot into restricted states, or use OS/manufacturer controls. It is not a tamper-proof kiosk/parental-control lock.
- Foreground services improve timer continuity but no app can guarantee survival against every OEM battery manager. Exemptions/auto-start settings may need to be configured by the device owner.
- The app uses a foreground service and Accessibility service. Sideloading is suitable for personal use; Google Play distribution has additional policy requirements for Accessibility API use.
- Android 13+ may ask for notification permission. Grant it so timer and completion notifications are visible.
- Full-screen alarm presentation depends on Android permission and notification settings; otherwise the alarm is available from its notification.
- If the process is killed by the OS, the timer is not restored after process death in this starter. Keep FocusBoard exempt from aggressive battery optimization if the device offers that setting.

## Build APK from a phone using GitHub
1. Download and extract the ZIP.
2. Create a repository at https://github.com/new.
3. Upload all extracted contents to the repository root. Ensure `.github/workflows/android.yml` is uploaded.
4. Open **Actions** and run **Build FocusBoard APK** (or push to main/master).
5. Open the successful run and download artifact **FocusBoard-2.0-debug-apk**.
6. Extract the artifact ZIP and install `app-debug.apk`.

The workflow creates a debug APK for personal testing. A Play Store release needs a signed release build and Play policy review.

## Directory map

```text
FocusBoard-Complete/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/focusboard/
│       │   ├── MainActivity.kt
│       │   ├── FocusService.kt
│       │   ├── FocusAccessibilityService.kt
│       │   ├── BlockedActivity.kt
│       │   ├── AlarmActivity.kt
│       │   └── PlannerStore.kt
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/strings.xml
│           └── xml/focus_accessibility_config.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```


## UI refresh
The main screen now uses a dark navy, teal-accented, rounded-card layout inspired by the supplied StudyLock reference: overview card, focus controls, syllabus entry, date field, and generated daily plan. This is a native Android XML UI, not a static mockup.
